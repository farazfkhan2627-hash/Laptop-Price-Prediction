import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

df = pd.read_csv("data/laptop_price_dataset.csv")

X = df.drop(columns=["Price_INR"])
y = df["Price_INR"]

categorical = ["Brand", "Type", "GPU_Type"]
numeric = ["Screen_Size_Inches", "RAM_GB", "Storage_GB"]

preprocessor = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
    ("num", "passthrough", numeric)
])

model = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor", LinearRegression())
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)

model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Model Evaluation")
print("----------------")
print(f"MAE:  ₹{mean_absolute_error(y_test, predictions):,.2f}")
print(f"RMSE: ₹{np.sqrt(mean_squared_error(y_test, predictions)):,.2f}")
print(f"R²:   {r2_score(y_test, predictions):.4f}")

with open("models/laptop_price_model.pkl", "wb") as file:
    pickle.dump(model, file)

print("\nModel saved to models/laptop_price_model.pkl")
