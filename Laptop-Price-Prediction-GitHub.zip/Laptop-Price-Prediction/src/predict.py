import pickle
import pandas as pd

with open("models/laptop_price_model.pkl", "rb") as file:
    model = pickle.load(file)

print("Laptop Price Prediction")
print("-----------------------")

brand = input("Brand (HP/Dell/Lenovo/ASUS/Acer/Apple/MSI): ")
laptop_type = input("Type (Notebook/Ultrabook/Gaming): ")
screen_size = float(input("Screen size in inches: "))
ram = int(input("RAM in GB: "))
storage = int(input("Storage in GB: "))
gpu_type = input("GPU Type (Integrated/Dedicated): ")

laptop = pd.DataFrame([{
    "Brand": brand,
    "Type": laptop_type,
    "Screen_Size_Inches": screen_size,
    "RAM_GB": ram,
    "Storage_GB": storage,
    "GPU_Type": gpu_type
}])

prediction = model.predict(laptop)[0]

print(f"\nEstimated Laptop Price: ₹{prediction:,.2f}")
